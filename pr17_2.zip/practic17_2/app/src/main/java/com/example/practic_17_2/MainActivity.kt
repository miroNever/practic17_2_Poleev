package com.example.practic_17_2

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    lateinit var pref: SharedPreferences
    lateinit var ed: Editor
    lateinit var Fon : ConstraintLayout
    lateinit var CountText: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Fon = findViewById(R.id.fon)
        Fon.setBackgroundColor(getColor(R.color.red))
        pref = getPreferences(MODE_PRIVATE)
        ed = pref.edit()
        var count:Int
        count = pref.getInt("count", 0)
        count = count + 1
        ed.putInt("count", count)
        ed.apply()

        CountText = findViewById(R.id.count)
        CountText.text = "Количество запусков: " + pref.getInt("count", count)
        if(pref.getInt("count", count)  % 2 != 0 && pref.getInt("count", count) != 1)
        {
            Fon.setBackgroundColor(getColor(R.color.blue))
        }
        else if(pref.getInt("count", count) % 2 == 0)
        {
            Fon.setBackgroundColor(getColor(R.color.green))
        }
    }
}